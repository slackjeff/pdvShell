# 🧾PDVShell

<palign="centro">
<img src="assets/demo.gif" alt="PDVShell Demo" width="700"/>
</p>

<palign="centro">
<img src="https://img.shields.io/badge/shell-bash-blue?style=flat-square"/>
<img src="https://img.shields.io/badge/database-sqlite-lightgrey?style=flat-square"/>
<img src="https://img.shields.io/badge/license-MIT-green?style=flat-square"/>
<img src="https://img.shields.io/badge/platform-linux-orange?style=flat-square"/>
<img src="https://img.shields.io/badge/focus-low--end%20systems-red?style=flat-square"/>
</p>

---

## 📌 A proposito

**PDVShell** è un sistema di registratore di cassa (POS) leggero ed efficiente, sviluppato in **Shell Script + SQLite**.

Ideale per i piccoli negozi di alimentari che necessitano di qualcosa di semplice, veloce e affidabile.

---

## 🚀 Caratteristiche

- 📦 Registrazione e gestione del prodotto
- 🏪 Controllo dei fornitori
- 💰 Record di vendite
- 📊 Rapporti
- ⚙️ Impostazioni
- 🧾 Controllo delle scorte

---

## 🧠 Filosofia

- Semplice e diretto
- Nessuna dipendenza pesante
- Terminale di radice
- Funziona anche su una vecchia macchina

---

## 📦 Installazione

Scegli una delle opzioni seguenti:

### 🔹 Metodo 1 — arricciatura (veloce e diretto)
```bash
curl -LO https://raw.githubusercontent.com/slackjeff/pdvShell/main/install.sh
sudo bash install.sh
```

---

### 🔹 Metodo 2 — wget (alternativa a curl)
```bash
wget https://raw.githubusercontent.com/slackjeff/pdvShell/main/install.sh
sudo bash install.sh
```

---

### 🔹 Metodo 3 — git (consigliato per lo sviluppo)
```bash
git clone --depth=1 https://github.com/slackjeff/pdvShell
cd pdvShell
sudo bash install.sh
```

---

## ⚠️ Osservazioni

- Lo script **deve essere eseguito come root** (`sudo`).
- Per maggiore sicurezza, rivedere i contenuti prima di eseguire:
  ```bash
  less install.sh
  ```
- Si consiglia di testare in un ambiente di sviluppo prima di utilizzarlo in produzione.

---

## 🧠 Consiglio pratico

Se prevedi di aggiornare o modificare il progetto in un secondo momento, utilizza **git**.
Se vuoi semplicemente installarlo velocemente, **curl** o **wget** faranno il trucco in pochi secondi.

---

## ▶️ Utilizzo/Esecuzione

```bash
pdvshell
```
---

# 🖥️Interfaccia completa

## 📋 Menù

![Menu Produtos](assets/mercearia-menu-produtos.png)
![Menu Fornecedores](assets/mercearia-menu-fornecedores.png)
![Menu Movimento](assets/mercearia-menu-movimento.png)
![Menu Relatório](assets/mercearia-menu-relatorio.png)
![Menu Consultas](assets/mercearia-menu-consultas.png)
![Menu Manutenção](assets/mercearia-menu-manutencao.png)
![Menu Configuração](assets/mercearia-menu-configuracao.png)
![Menu Sobre](assets/mercearia-menu-sobre.png)

---

## 📦 Prodotti

![Cadastro](assets/mercearia-produtos-cadastro.png)
![Exclusão](assets/mercearia-produtos-exclusao.png)
![Pesquisar](assets/mercearia-produtos-pesquisar.png)
![Vendidos](assets/mercearia-produtos-vendidos.png)
![Compra](assets/mercearia-produtos-compra.png)
![Vendas](assets/mercearia-produtos-vendas.png)
![Entradas](assets/mercearia-produtos-entradas.png)
![Abaixo do mínimo](assets/mercearia-produtos-abaixo-do-minimo.png)
![Validade](assets/mercearia-produtos-fora-de-validade.png)

---

## 🏪 Fornitori

![Cadastro fornecedor](assets/mercearia-fornecedor-cadastro.png)
![Lista fornecedor](assets/mercearia-fornecedor-listagem.png)

---

## 📊 Rapporti

![Vendas diárias](assets/mercearia-exibir-vendas-diarias.png)

---

## ⚙️ Impostazioni

![Menu config](assets/mercearia-menu-configuracao.png)
![Cores](assets/configuracao-de-cores.png)
![Empresa](assets/mercearia-configuracao-dados-empresa.png)

---

## ℹ️ A proposito

![Sobre](assets/mercearia-sobre-sobre.png)
![Sair](assets/mercearia-menu-sair.png)

---

## 🛠️Tabella di marcia

- [] Backup automatico
- [ ] Multiutente
- [ ] Stampa
- [ ] Esportazione CSV/PDF

---

## 📄 Licenza

CON
